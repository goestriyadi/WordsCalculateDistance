package com.goes.WordCalculateDistance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordCalculateDistanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordCalculateDistanceApplication.class, args);
	}

}
